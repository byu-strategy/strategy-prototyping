---
name: quarto-slides
description: Create RevealJS slide decks from Quarto chapter files for course presentations. Use this skill when converting course chapter .qmd files into presentation slides, generating lecture materials, or creating slide decks from existing Quarto book content. Handles content transformation, styling, and slide structure optimization.
---

# Quarto Slides Generator

## Overview

Transform Quarto book chapters into professional RevealJS slide decks optimized for teaching and presentations. This skill automates the conversion of markdown chapter files into well-structured slides with course branding, appropriate content density, and clean formatting.

## When to Use This Skill

Invoke this skill when:
- Converting a Quarto chapter file (.qmd) into presentation slides
- User requests "create slides from chapter X"
- Generating lecture materials from course notes
- User asks to "make a slide deck" or "create a presentation" from existing content
- Transforming book content into presentation format

## Quick Start

**Typical user request:**
> "Create slides from chapter 3"
> "Generate a slide deck for 01-pm-ai-era.qmd"
> "Convert the AI strategy chapter into presentation slides"

**Basic workflow:**
1. Identify the source chapter file
2. Run the conversion script
3. Copy the custom theme file to the project
4. Preview and refine the generated slides
5. Deliver the final slide deck file

## Conversion Process

### Step 1: Locate Source Chapter

Identify which chapter file to convert. Common patterns:
- By number: "chapter 3" → look for `03-*.qmd`
- By filename: "01-pm-ai-era.qmd"
- By topic: "AI strategy" → search for matching chapter title

Use Glob to find chapter files if the exact name is unclear:
```bash
# Find all chapter files
glob "*.qmd" in project directory
# Or use Bash to list numbered chapters
ls [0-9][0-9]-*.qmd
```

### Step 2: Run Conversion Script

Execute `scripts/convert_to_slides.py` to transform the chapter into slides:

```bash
python scripts/convert_to_slides.py path/to/chapter.qmd
# Output: chapter-slides.qmd in same directory
```

**What the script does:**
- Extracts chapter title from YAML frontmatter
- Converts `##` headings into individual slides
- Converts `###` subheadings into additional slides
- Cleans content for slide format (removes embedded tweets, truncates long lists)
- Splits overly long paragraphs
- Generates title slide with course branding
- Adds final "Questions?" slide
- Creates RevealJS-formatted YAML frontmatter

**Script output format:**
- Input: `01-pm-ai-era.qmd` → Output: `01-pm-ai-era-slides.qmd`
- Custom output path: `python convert_to_slides.py input.qmd output.qmd`

### Step 3: Copy Theme File

Copy the custom SCSS theme to the project directory:

```bash
cp assets/custom.scss path/to/project/
```

The theme provides:
- BYU-inspired color scheme (navy #002E5D, royal blue #0057B8)
- Professional typography and spacing
- Styled code blocks with syntax highlighting
- Branded title slide with gradient background
- Consistent heading hierarchy
- Optimized image sizing and shadows

**Customization:** Users can modify `custom.scss` to change colors, fonts, or styling.

### Step 4: Preview Slides

Use Quarto to preview the generated slides:

```bash
quarto preview path/to/chapter-slides.qmd
```

This opens an interactive browser preview where slides can be:
- Navigated with arrow keys
- Tested for content density
- Reviewed for formatting issues
- Checked for proper image display

### Step 5: Refinement (Optional)

Common refinements after initial generation:

**Content density issues:**
- If slides are too dense, manually split into multiple slides
- Move supporting details to speaker notes
- Reduce bullet point count

**Formatting improvements:**
- Add incremental reveals for bullet lists (`. . .` syntax)
- Include speaker notes with `::: notes` blocks
- Add slide-specific classes for special formatting

**Example refinements:**
```markdown
## Key Concepts {.smaller}

- Point 1
- Point 2

::: notes
Additional context for the speaker that won't appear on slides.
:::
```

### Step 6: Render Final Slides

Generate the final HTML presentation:

```bash
quarto render path/to/chapter-slides.qmd
```

Output: Self-contained HTML file ready for presentation or distribution.

## Content Transformation Rules

The conversion script applies these transformations automatically:

### Slide Creation
- `##` headings → Individual slides
- `###` subheadings → Additional slides under the parent section
- Content before first heading → Optional intro slide (if substantial)

### Content Cleaning
- **Removed:** Embedded tweets, social media embeds, HTML script tags
- **Truncated:** Bullet lists longer than 6 items
- **Split:** Paragraphs longer than 500 characters converted to bullet points
- **Preserved:** Images, code blocks, blockquotes, links, formatting

### Slide Structure
1. **Title slide:** Chapter title, course subtitle, instructor name
2. **Content slides:** One per major heading/topic
3. **Final slide:** "Questions?" with thank you message

## Customization Options

### Instructor and Course Details

Modify the script to change defaults:
```python
create_slides_qmd(
    input_file,
    output_file,
    instructor="Your Name",
    course="COURSE 123"
)
```

### Theme Colors

Edit `assets/custom.scss` to customize:
```scss
$byu-navy: #002E5D;      // Primary color
$byu-royal: #0057B8;     // Accent color
```

### Logo

Add a logo by:
1. Place `logo.png` in project's `images/` directory (200x200px recommended)
2. Logo will automatically appear on slides (referenced in YAML frontmatter)

### RevealJS Options

The generated slides include these RevealJS features (configurable in YAML):
- `slide-number: true` - Show slide numbers
- `chalkboard: true` - Enable drawing on slides during presentation
- `preview-links: auto` - Preview links on hover
- `smaller: true` - Reduce default font size for dense content
- `scrollable: true` - Allow scrolling on oversized slides

## Troubleshooting

### Issue: Slides Too Dense
**Solution:** Manually edit generated file to split content across multiple slides

### Issue: Images Not Displaying
**Solution:** Verify image paths are relative to the slides file location. Update paths if chapter and slides are in different directories.

### Issue: Theme Not Applied
**Solution:** Ensure `custom.scss` is in the same directory as the slides file, or update the path in YAML frontmatter.

### Issue: Special Content Not Converting Well
**Solution:** Some complex Quarto syntax (custom divs, advanced layouts) may need manual adjustment after conversion.

## Example Workflow

**User request:** "Create slides for chapter 1"

**Assistant actions:**
1. Locate chapter: `01-pm-ai-era.qmd`
2. Run conversion:
   ```bash
   python scripts/convert_to_slides.py 01-pm-ai-era.qmd
   ```
3. Copy theme:
   ```bash
   cp assets/custom.scss .
   ```
4. Preview:
   ```bash
   quarto preview 01-pm-ai-era-slides.qmd
   ```
5. Report to user:
   - "Created `01-pm-ai-era-slides.qmd` with 15 slides"
   - "Preview the slides with: `quarto preview 01-pm-ai-era-slides.qmd`"
   - "Render final HTML with: `quarto render 01-pm-ai-era-slides.qmd`"

## Resources

### scripts/convert_to_slides.py
Python script that performs the chapter-to-slides transformation. Handles YAML parsing, content extraction, slide generation, and cleanup.

**Key functions:**
- `parse_yaml_frontmatter()` - Extract chapter metadata
- `extract_slides()` - Convert headings to slide structure
- `clean_slide_content()` - Optimize content for presentation format
- `format_slide()` - Generate RevealJS markdown syntax

### assets/custom.scss
RevealJS theme file with professional styling and course branding.

**Features:**
- BYU color scheme (navy and royal blue)
- Optimized typography and spacing
- Gradient title slide background
- Styled code blocks and blockquotes
- Responsive image sizing

### assets/README.md
Documentation for customizing theme assets and adding logos.

## Advanced Usage

### Batch Conversion
Convert multiple chapters at once:
```bash
for file in [0-9][0-9]-*.qmd; do
    python scripts/convert_to_slides.py "$file"
done
```

### Custom Slide Templates
Modify the script's `output_lines` section to change the standard title slide or final slide format.

### Incremental Reveals
Manually add to generated slides for progressive disclosure:
```markdown
## Key Points

::: {.incremental}
- First point
- Second point
- Third point
:::
```

### Speaker Notes
Add presenter notes to any slide:
```markdown
## Slide Title

Content visible to audience

::: notes
Notes only visible in presenter mode (press 's' during presentation)
:::
```

## Output Format

Generated slides use this YAML frontmatter structure:
```yaml
---
title: "Chapter Title"
subtitle: "STRAT 490R: Creating Digital Products with AI"
author: "Scott Murff"
format:
  revealjs:
    theme: [default, custom.scss]
    slide-number: true
    chalkboard: true
    preview-links: auto
    logo: images/logo.png
    footer: "STRAT 490R"
    smaller: true
    scrollable: true
---
```

Slides follow this markdown pattern:
```markdown
# Chapter Title

### STRAT 490R
Scott Murff

## First Topic

Content for first slide...

## Second Topic

Content for second slide...

## Questions?

### Thank you!

_STRAT 490R: Creating Digital Products with AI_
```
