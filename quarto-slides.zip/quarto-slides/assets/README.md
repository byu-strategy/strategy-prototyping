# Slide Deck Assets

This directory contains template files for creating Quarto RevealJS slide decks.

## Files

### custom.scss
RevealJS theme file with BYU-inspired styling (navy and royal blue colors).

**Usage:** This file will be automatically copied to your project directory and referenced in the generated slides YAML frontmatter.

## Optional Assets

### logo.png (optional)
Course or institutional logo to display in the corner of slides.

**How to add:** Place a `logo.png` file in your project's `images/` directory. The generated slides will reference it automatically.

**Recommended size:** 200x200px PNG with transparent background

## How Assets Are Used

When you use this skill to create slides:

1. **custom.scss** - Copied to your project directory, provides BYU-themed styling
2. **logo.png** - Referenced from your existing `images/` directory if present
3. The generated `.qmd` file references these assets in its YAML frontmatter

## Customization

You can modify `custom.scss` to:
- Change color scheme (update `$byu-navy` and `$byu-royal` variables)
- Adjust font sizes (modify `.reveal` font-size rules)
- Customize heading styles
- Add institutional branding
