#!/usr/bin/env python3
"""
Convert Quarto chapter files to RevealJS slide decks.

Usage:
    python convert_to_slides.py <input.qmd> [output.qmd]
"""

import re
import sys
from pathlib import Path
from typing import List, Tuple


def parse_yaml_frontmatter(content: str) -> Tuple[dict, str]:
    """Extract YAML frontmatter and return it with remaining content."""
    if not content.startswith('---'):
        return {}, content

    parts = content.split('---', 2)
    if len(parts) < 3:
        return {}, content

    yaml_content = parts[1].strip()
    remaining = parts[2]

    # Parse simple YAML (title only for now)
    yaml_dict = {}
    for line in yaml_content.split('\n'):
        if ':' in line:
            key, value = line.split(':', 1)
            yaml_dict[key.strip()] = value.strip().strip('"')

    return yaml_dict, remaining


def extract_slides(content: str) -> List[dict]:
    """Convert markdown content to slide structure."""
    slides = []

    # Split by ## headings (main slides)
    sections = re.split(r'^## ', content, flags=re.MULTILINE)

    for i, section in enumerate(sections):
        if not section.strip():
            continue

        # First section might be intro content before any heading
        if i == 0:
            # Skip intro tweets/embeds, or create a content slide if substantial
            if len(section.strip()) > 100 and not section.strip().startswith('::: tweet'):
                slides.append({
                    'title': None,
                    'content': section.strip(),
                    'level': 0
                })
            continue

        # Split title from content
        lines = section.split('\n', 1)
        title = lines[0].strip()
        slide_content = lines[1].strip() if len(lines) > 1 else ''

        # Check for ### subsections
        subsections = re.split(r'^### ', slide_content, flags=re.MULTILINE)

        if len(subsections) > 1:
            # Create main slide with content before first subsection
            main_content = subsections[0].strip()
            if main_content:
                slides.append({
                    'title': title,
                    'content': main_content,
                    'level': 2
                })

            # Create slides for each subsection
            for subsection in subsections[1:]:
                sub_lines = subsection.split('\n', 1)
                sub_title = sub_lines[0].strip()
                sub_content = sub_lines[1].strip() if len(sub_lines) > 1 else ''
                slides.append({
                    'title': sub_title,
                    'content': sub_content,
                    'level': 3
                })
        else:
            slides.append({
                'title': title,
                'content': slide_content,
                'level': 2
            })

    return slides


def clean_slide_content(content: str, max_items: int = 6) -> str:
    """Clean and optimize content for slides."""
    # Remove embedded tweets and social media (too complex for slides)
    content = re.sub(r'::: tweet-center.*?:::', '', content, flags=re.DOTALL)
    content = re.sub(r'::: embed-center.*?:::', '', content, flags=re.DOTALL)
    content = re.sub(r'```\{=html\}.*?```', '', content, flags=re.DOTALL)

    # Truncate long bullet lists
    lines = content.split('\n')
    bullet_count = 0
    cleaned_lines = []

    for line in lines:
        if line.strip().startswith('-'):
            bullet_count += 1
            if bullet_count <= max_items:
                cleaned_lines.append(line)
        else:
            bullet_count = 0
            cleaned_lines.append(line)

    content = '\n'.join(cleaned_lines)

    # Split very long paragraphs
    paragraphs = content.split('\n\n')
    short_paragraphs = []
    for para in paragraphs:
        if len(para) > 500 and not para.strip().startswith('!['):
            # Split long paragraphs into bullet points if possible
            sentences = para.split('. ')
            if len(sentences) > 2:
                bullets = '\n'.join([f"- {s.strip()}." for s in sentences if s.strip()])
                short_paragraphs.append(bullets)
            else:
                short_paragraphs.append(para)
        else:
            short_paragraphs.append(para)

    return '\n\n'.join(short_paragraphs).strip()


def format_slide(slide: dict, instructor: str = "Scott Murff") -> str:
    """Format a single slide in RevealJS markdown format."""
    if slide['level'] == 0:
        # Intro content slide
        return f"## \n\n{clean_slide_content(slide['content'])}\n"

    title = slide['title']
    content = clean_slide_content(slide['content'])

    # Use ## for all slides (RevealJS uses ## for horizontal slides)
    return f"## {title}\n\n{content}\n"


def create_slides_qmd(
    input_file: Path,
    output_file: Path,
    instructor: str = "Scott Murff",
    course: str = "STRAT 490R"
) -> None:
    """Convert chapter QMD to RevealJS slides QMD."""

    # Read input file
    content = input_file.read_text(encoding='utf-8')

    # Parse frontmatter
    yaml_data, markdown_content = parse_yaml_frontmatter(content)
    chapter_title = yaml_data.get('title', input_file.stem)

    # Extract slides
    slides = extract_slides(markdown_content)

    # Build output
    output_lines = [
        '---',
        f'title: "{chapter_title}"',
        f'subtitle: "{course}: Creating Digital Products with AI"',
        f'author: "{instructor}"',
        'format:',
        '  revealjs:',
        '    theme: [default, custom.scss]',
        '    slide-number: true',
        '    chalkboard: true',
        '    preview-links: auto',
        '    logo: images/logo.png',
        '    footer: "{{< meta course >}}"',
        '    smaller: true',
        '    scrollable: true',
        'execute:',
        '  enabled: false',
        '---',
        '',
        f'# {chapter_title}',
        '',
        f'### {course}',
        f'{instructor}',
        ''
    ]

    # Add slides
    for slide in slides:
        output_lines.append(format_slide(slide, instructor))
        output_lines.append('')

    # Add final slide
    output_lines.extend([
        '## Questions?',
        '',
        '### Thank you!',
        '',
        f'_{course}: Creating Digital Products with AI_',
        ''
    ])

    # Write output
    output_file.write_text('\n'.join(output_lines), encoding='utf-8')
    print(f"✅ Created slides: {output_file}")
    print(f"   Slides generated: {len(slides) + 2}")  # +2 for title and questions


def main():
    """Main entry point."""
    if len(sys.argv) < 2:
        print("Usage: python convert_to_slides.py <input.qmd> [output.qmd]")
        sys.exit(1)

    input_path = Path(sys.argv[1])
    if not input_path.exists():
        print(f"Error: File not found: {input_path}")
        sys.exit(1)

    # Determine output path
    if len(sys.argv) > 2:
        output_path = Path(sys.argv[2])
    else:
        output_path = input_path.parent / f"{input_path.stem}-slides.qmd"

    create_slides_qmd(input_path, output_path)

    print(f"\nNext steps:")
    print(f"1. Review and edit: {output_path}")
    print(f"2. Preview slides: quarto preview {output_path}")
    print(f"3. Render slides: quarto render {output_path}")


if __name__ == '__main__':
    main()
